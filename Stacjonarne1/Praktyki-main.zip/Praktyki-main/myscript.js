const people1 = ["John Doe", "Jane Lopez"];
const people2 = ["John Smith", "Kyle Rogers"];
const numbers = [1, 2, 5, 10, 20];

